## About IdentityModel

IdentityModel is a .NET standard helper library for claims-based identity, OAuth 2.0 and OpenID Connect.

For project documentation, please visit [readthedocs](https://identitymodel.readthedocs.io).
