$ErrorActionPreference = "Stop";
dotnet run --project build -- $args
